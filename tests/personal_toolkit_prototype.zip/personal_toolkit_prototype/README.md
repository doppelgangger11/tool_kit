# Personal Toolkit — UI Engine Prototype

Прототип конфигурируемого Desktop UI на CustomTkinter.

## Запуск

```bash
py -m pip install customtkinter
py app.py
```

При первом запуске приложение создаёт `ui_config.json` и `projects.json`, если их нет.

## Архитектура

- `app.py` — оболочка приложения, UI Renderer и Action Dispatcher.
- `projects.json` — реестр проектов и декларативное описание их интерфейсов.
- `ui_config.json` — глобальные настройки интерфейса (заготовка).

UI строится из `project["ui"]["widgets"]`. Core-код проектов пока не подключён:
`run_demo` — демонстрационный обработчик, который нужно заменить вызовом адаптера Core.

## Как добавить действие

1. Добавьте в `ActionDispatcher.__init__` запись `"my_action": self.my_action`.
2. Реализуйте метод `my_action(self, params)`.
3. В `projects.json` у нужного проекта укажите `"action": "my_action"`.

## Важно для следующего этапа

Не переносите бизнес-логику в `app.py`. Вынесите регистрацию Core-функций в отдельный `core_registry.py`,
а параметры конкретных проектов храните в конфигурации. Следующий разумный шаг — добавить типы виджетов
`file_picker`, `text_input`, `checkbox`, `dropdown`, `progress`, `log_view` и механизм валидации схемы.
